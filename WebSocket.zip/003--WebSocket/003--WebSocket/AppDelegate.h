//
//  AppDelegate.h
//  003--WebSocket
//
//  Created by vampire on 2018/5/3.
//  Copyright © 2018年 vampire. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

